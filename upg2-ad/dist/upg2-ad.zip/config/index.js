/* eslint-disable import/no-unresolved */

/* eslint-disable global-require */
// index.js
(function init() {
  var router = require('router');

  var portletContextUtil = require('PortletContextUtil');

  var properties = require('Properties');

  var appInfo = require('appInfo');

  router.get('/', function (req, res) {
    var currentUserEmail = properties.get(portletContextUtil.getCurrentUser(), 'mail');
    var appName = appInfo.appName;
    res.render({
      currentUserEmail: currentUserEmail,
      appName: appName
    });
  });
})();