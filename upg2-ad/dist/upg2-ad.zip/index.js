/* eslint-disable import/no-unresolved */

/* eslint-disable global-require */
(function () {
  var router = require('router');

  var ads = require('./AdsDS');

  var appData = require('appData');

  router.get('/', function (req, res) {
    var maxAds = appData.get('maxAds');
    res.render('/', {
      ads: ads.getAllAds(maxAds)
    });
  });
  router.get('/ad', function (req, res) {
    res.render('/ad', {
      ad: ads.getAllAds(req.params.id)
    });
  });
})();