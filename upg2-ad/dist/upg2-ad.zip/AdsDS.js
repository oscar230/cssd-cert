/* eslint-disable consistent-return */

/* eslint-disable import/no-unresolved */

/* eslint-disable no-undef */
// AdsDS.js
define(function (require) {
  var storage = require('storage');

  var ads = storage.getCollectionDataStore('ads');

  var logUtil = require('LogUtil'); // Define this module


  return {
    getAllAds: function getAllAds() {
      var max = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 10;

      try {
        return ads.find('*', parseInt(max, 10)).toArray();
      } catch (e) {
        logUtil.error(e);
        return false;
      }
    },
    getAd: function getAd(id) {
      try {
        return ads.get(id).toArray();
      } catch (e) {
        logUtil.error(e);
        return false;
      }
    },
    editAd: function editAd(id, member) {
      try {
        ads.set(id, member).instantIndex();
      } catch (e) {
        logUtil.error(e);
        return false;
      }

      return true;
    },
    remove: function remove(id) {
      try {
        ads.remove(id).instantIndex();
      } catch (e) {
        logUtil.error(e);
      }
    },
    search: function search(condition) {
      var query = "ds.analyzed.name:".concat(condition, "*");

      try {
        return ads.find(query, 100).toArray();
      } catch (e) {
        logUtil.error(e);
        return false;
      }
    }
  };
});