/* eslint-disable import/no-unresolved */
// eslint-disable-next-line no-undef
define(function (require) {
  var ListComponent = require('ListComponent');

  return ListComponent.extend({
    tagName: 'ul',
    childProperty: 'ads',
    childComponentPath: 'Ads',
    filterState: function filterState(_ref) {
      var ads = _ref.ads;
      return {
        ads: ads
      };
    }
  });
});