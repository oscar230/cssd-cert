/* eslint-disable consistent-return */

/* eslint-disable no-undef */

/* eslint-disable import/no-unresolved */
define(function (require) {
  var Component = require('Component');

  var logUtil = require('LogUtil');

  var adsTemplate = require('./template/Ads');

  var adTemplate = require('./template/Ad');

  var adEditTemplate = require('./template/adEditTemplate');

  return Component.extend({
    getTemplate: function getTemplate() {
      if (this.state.route === '/') {
        return adsTemplate;
      }

      if (this.state.route === '/ad') {
        return adTemplate;
      }

      if (this.state.route === '/edit') {
        return adEditTemplate;
      }

      logUtil.error("Route ".concat(this.state.route, " does not exist."));
    },
    className: 'up2-ad',
    filterState: function filterState(_ref) {
      var route = _ref.route,
          name = _ref.name;
      return {
        route: route,
        name: name
      };
    }
  });
});