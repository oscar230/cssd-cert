/* eslint-disable no-undef */

/* eslint-disable import/no-unresolved */
define(function (require) {
  var Component = require('Component');

  return Component.extend({// code...
  });
});