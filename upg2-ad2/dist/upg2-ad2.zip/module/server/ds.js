/* eslint-disable import/no-unresolved */
// eslint-disable-next-line no-undef
define(function (require) {
  var storage = require('storage');

  var ads = storage.getCollectionDataStore('ads');

  var logUtil = require('LogUtil');

  var MAX = 100;
  return {
    get: function get(id) {
      try {
        if (typeof id !== 'undefined') {
          return ads.get(id);
        }

        return ads.find('*', parseInt(MAX, 10)).toArray();
      } catch (e) {
        logUtil.error(e);
        return e;
      }
    },
    search: function search(term) {
      try {
        return ads.find(term, parseInt(MAX, 10));
      } catch (e) {
        logUtil.error(e);
        return e;
      }
    },
    add: function add(ad) {
      try {
        var data = ads.add(ad);
        ads.instantIndex(data.dsid);
        return true;
      } catch (e) {
        logUtil.error(e);
        return e;
      }
    },
    edit: function edit(id, ad) {
      try {
        if (typeof ad.title !== 'undefined' && typeof ad.contact === 'undefined') {
          ads.set(id, ad);
          return true;
        }

        return false;
      } catch (e) {
        logUtil.error(e);
        return e;
      }
    },
    remove: function remove(id) {
      try {
        ads.remove(id).instantIndex();
        return true;
      } catch (e) {
        logUtil.error(e);
        return e;
      }
    }
  };
});