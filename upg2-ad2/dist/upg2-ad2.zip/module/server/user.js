/* eslint-disable import/no-unresolved */
// eslint-disable-next-line no-undef
define(function (require) {
  var PCU = require('PortletContextUtil');

  var properties = require('Properties');

  var logUtil = require('LogUtil');

  return {
    currentUserName: function currentUserName() {
      try {
        return PCU.getCurrentUserIdentity().toString();
      } catch (e) {
        logUtil.error(e);
        return e;
      }
    },
    currentUserId: function currentUserId() {
      try {
        return PCU.getCurrentUser().toString();
      } catch (e) {
        logUtil.error(e);
        return e;
      }
    },
    getUser: function getUser(id) {
      try {
        return {
          id: id,
          name: properties.get('id', 'displayName')
        };
      } catch (e) {
        logUtil.error(e);
        return e;
      }
    }
  };
});