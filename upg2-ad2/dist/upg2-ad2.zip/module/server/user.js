/* eslint-disable import/no-unresolved */
// eslint-disable-next-line no-undef
define(function (require) {
  var PCU = require('PortletContextUtil');

  var properties = require('Properties');

  var logUtil = require('LogUtil');

  return {
    currentUser: function currentUser() {
      try {
        return PCU.getCurrentUserIdentity();
      } catch (e) {
        logUtil.error(e);
        return e;
      }
    },
    getUser: function getUser(id) {
      try {
        return {
          id: id,
          name: properties.get('id', 'displayName')
        };
      } catch (e) {
        logUtil.error(e);
        return e;
      }
    }
  };
});