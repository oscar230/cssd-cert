/* eslint-disable import/no-unresolved */

/* eslint-disable global-require */
(function init() {
  var router = require('router');

  var appInfo = require('appInfo');

  router.get('/', function (req, res) {
    res.render({
      title: appInfo.appName
    });
  });
})();