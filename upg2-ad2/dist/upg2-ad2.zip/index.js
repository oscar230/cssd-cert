/* eslint-disable import/no-unresolved */

/* eslint-disable global-require */
(function init() {
  var router = require('router');

  var i18n = require('i18n');

  router.get('/', function (req, res) {
    var title = i18n.get('title');
    var message = i18n.get('showingAll');
    res.render('/', {
      title: title,
      message: message
    });
  });
})();