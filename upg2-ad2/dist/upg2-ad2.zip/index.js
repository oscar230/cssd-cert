/* eslint-disable import/no-absolute-path */

/* eslint-disable import/no-unresolved */

/* eslint-disable global-require */
(function init() {
  var router = require('router');

  var ads = require('/module/server/ds');

  var user = require('/module/server/user');

  var randomAd = require('/module/server/randomAd');

  var logUtil = require('LogUtil'); // Users need to authenticate before.


  var authenticatedPaths = ['/ad', '/add', '/edit', '/rnd', '/add']; // Middleware for authenticated links

  router.use(function (req, res, next) {
    if (authenticatedPaths.includes(req.path) && user.currentUserId() === 'Anonymous') {
      res.send('<p><b>Error!</b><br>You need to authenticate before performing this opertion!</p><br><a href="/">Go home</a>');
    } else {
      next();
    }
  }); // HTML for all list and ROOT

  router.get('/', function (req, res) {
    res.render('/', {
      adList: ads.get()
    });
  }); // HTML get one specfic

  router.get('/ad', function (req, res) {
    res.render('/ad', {
      ad: ads.get(req.params.id)
    });
  }); // HTML for adding

  router.get('/add', function (req, res) {
    res.render('/add');
  }); // HTML for editing

  router.get('/edit', function (req, res) {
    res.render('/edit', {
      ad: ads.get(req.params.id)
    });
  }); // HTML for reporting

  router.get('/report', function (req, res) {
    var ad = ads.get(req.params.id);

    if (typeof ad !== 'undefined' && user.currentUserId() !== ad.contact) {
      res.render('/report', {
        ad: ad
      });
    } else {
      res.send('<p>You cannot report your own content!</p>');
    }
  }); // DS Random ad

  router.post('/rnd', function (req, res) {
    ads.add(randomAd.getAd(user.currentUserId()));
    res.render('/', {
      adList: ads.get()
    });
  }); // DS Add

  router.post('/add', function (req, res) {
    ads.add({
      title: req.params.title,
      content: req.params.content,
      link: req.params.link,
      price: req.params.price,
      imageLink: req.params.imageLink,
      contact: user.currentUserId(),
      contactNumber: req.params.contactNumber,
      contactEmail: req.params.contactEmail,
      reports: []
    });
    res.render('/', {
      adList: ads.get()
    });
  }); // DS Edit

  router.post('/edit', function (req, res) {
    ads.edit(req.params.id, {
      title: req.params.title,
      content: req.params.content,
      link: req.params.link,
      price: req.params.price,
      imageLink: req.params.imageLink,
      contact: user.currentUserId(),
      contactNumber: req.params.contactNumber,
      contactEmail: req.params.contactEmail,
      reports: ads.get(req.params.id).reports
    });
    res.render('/', {
      adList: ads.get()
    });
  }); // DS Remove

  router.post('/remove', function (req, res) {
    ads.remove(req.params.id);
    res.render('/', {
      adList: ads.get()
    });
  }); // DS Remove all

  router.post('removeAll', function (req, res) {
    var CUI = user.currentUserId();
    ads.get().filter(function (adc) {
      return adc.contact === CUI;
    }).forEach(function (adr) {
      return ads.remove(adr.dsid);
    });
    res.render('/', {
      adList: ads.get()
    });
  }); // DS Report

  router.post('/report', function (req, res) {
    try {
      var ad = ads.get(req.params.id);
      ad.reports.append({
        reason: req.params.reason,
        user: user.currentUserId()
      });
      ads.edit(ad.id, ad);
      res.send(JSON.stringify(ads.get(ad.id).reports));
    } catch (e) {
      logUtil.error(e);
      res.send(JSON.stringify(e));
    }

    res.render('/', {
      adList: ads.get()
    });
  });
})(); // res.redirect('/'); Jag kunde inte lista ut hur denna funkar, hade varit bra
// på vissa ställen. Mvh Oscar.