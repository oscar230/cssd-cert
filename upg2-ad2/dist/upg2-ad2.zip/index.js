/* eslint-disable import/no-absolute-path */

/* eslint-disable import/no-unresolved */

/* eslint-disable global-require */
(function init() {
  var router = require('router');

  var i18n = require('i18n');

  var ads = require('/module/server/ds');

  router.get('/', function (req, res) {
    res.render('/', {
      title: i18n.get('title'),
      message: i18n.get('showingAll')
    });
  });
  router.get('/:id', function (req, res) {
    res.render('/', {
      title: i18n.get('title'),
      message: i18n.get('showingSome'),
      id: req.params.id
    });
  });
  router.post('/', function (req, res) {
    ads.add({
      title: req.params.title,
      content: req.params.content,
      link: new URL(req.params.link).href
    });
    res.render('/posted', {
      title: i18n.get('title'),
      message: i18n.get('added')
    });
  });
})();