/* eslint-disable import/no-unresolved */

/* eslint-disable no-undef */
define(function (require) {
  var ListComponent = require('ListComponent');

  return ListComponent.extend({
    tagName: 'ul',
    childProperty: 'ads',
    childComponentPath: 'Ad',
    filterState: function filterState(_ref) {
      var ads = _ref.ads;
      return {
        ads: ads
      };
    }
  });
});