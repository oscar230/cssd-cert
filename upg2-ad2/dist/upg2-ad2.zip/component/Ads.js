/* eslint-disable import/no-unresolved */

/* eslint-disable no-undef */
define(function (require) {
  var ListComponent = require('ListComponent');

  return ListComponent.extend({
    childProperty: 'adList',
    childComponentPath: 'Ad',
    filterState: function filterState(_ref) {
      var adList = _ref.adList;
      return {
        adList: adList
      };
    }
  });
});