/* eslint-disable import/no-absolute-path */

/* eslint-disable import/no-unresolved */
// eslint-disable-next-line no-undef
define(function (require) {
  var Component = require('Component');

  var template = require('/template/ad');

  var user = require('/module/server/user');

  return Component.extend({
    tagName: 'tr',
    template: template,
    filterState: function filterState() {
      return {
        owner: user.currentUserId()
      };
    }
  });
});