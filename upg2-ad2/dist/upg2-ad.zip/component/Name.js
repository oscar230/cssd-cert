define(function (require) {
  'use strict';

  var Component = require('Component');

  var template = require('/template/name');

  return Component.extend({
    template: template,
    filterState: function filterState(_ref) {
      var name = _ref.name;
      return {
        name: name
      };
    }
  });
});