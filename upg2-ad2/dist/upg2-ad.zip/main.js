define(function (require) {
  'use strict';

  var Component = require('Component');

  var template = require('/template/main');

  return Component.extend({
    template: template,
    className: 'webapp-boilerplate',
    filterState: function filterState(_ref) {
      var message = _ref.message;
      return {
        message: message
      };
    }
  });
});