/* eslint-disable import/no-unresolved */

/* eslint-disable global-require */
(function init() {
  var router = require('router');

  var events = require('events');

  var rlu = require('ResourceLocatorUtil');

  var mailBuilder = require('MailBuilder');

  var log = require('LogUtil');

  var searcherBuilder = require('SearcherBuilder');

  var properties = require('Properties');

  events.on('sv:publishing:publish', function (options) {
    var page = rlu.getNodeByIdentifier(options.node);
    log.info("Handling sv:publishing:publish, options: ".concat(JSON.stringify(options)));
    var mail = mailBuilder.setSubject("".concat(page, " was published.")).setTextMessage("".concat(options.emitter, " published ").concat(page, ".")).addRecipient('oscar.andersson@soleil.se').build();
    mail.send();
  });
  events.on('sv:trashcan:add', function (options) {
    var page = rlu.getNodeByIdentifier(options.node);
    log.info("Handling sv:publishing:publish, options: ".concat(JSON.stringify(options)));
    var mail = mailBuilder.setSubject("".concat(page, " was added to the trashcan.")).setTextMessage("".concat(options.emitter, " published ").concat(page, ".")).addRecipient('oscar.andersson@soleil.se').build();
    mail.send();
  });
  router.post('/search', function (req, res) {
    var searchResults = searcherBuilder.build().search(req.params.name, 10);

    if (searchResults.hasHits()) {
      var array = properties.getArray(searchResults.hits, 'displayName');
      res.json({
        searchHits: array
      });
    }
  });
  router.get('/myroute', function (req, res) {
    res.json({
      message: 'Hello from GET'
    });
  });
  router.post('/myroute', function (req, res) {
    res.json({
      message: 'Hello from POST'
    });
  });
  router.put('/myroute', function (req, res) {
    res.json({
      message: 'Hello from PUT'
    });
  });
  router["delete"]('/myroute', function (req, res) {
    res.json({
      message: 'Hello from DELETE'
    });
  });
})();