define(function (require) {
  'use strict';

  var Component = require('Component');

  var template = require('/template/main');

  return Component.extend({
    template: template,
    className: 'webapp-boilerplate',
    events: {
      dom: {
        'click button': 'handleButtonClick'
      },
      state: {
        "state:changed": "render"
      }
    },
    handleButtonClick: function handleButtonClick(event) {
      console.log(event);
      console.log(this.$('input[name="message"]').val());
      this.setState('message', this.$('input[name="message"]').val());
    },
    filterState: function filterState(_ref) {
      var message = _ref.message;
      return {
        message: message
      };
    }
  });
});