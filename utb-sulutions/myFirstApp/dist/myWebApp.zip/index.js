(function () {
  'use strict';

  var router = require('router');

  var appData = require('appData');

  router.get('/', function (req, res) {
    var message = 'Hello, world!';
    res.render('/', {
      message: message
    });
  });
})();