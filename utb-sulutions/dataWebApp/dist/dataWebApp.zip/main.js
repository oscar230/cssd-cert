/* eslint-disable import/no-absolute-path */

/* eslint-disable func-names */

/* eslint-disable object-shorthand */

/* eslint-disable import/no-unresolved */
// eslint-disable-next-line no-undef
define(function (require) {
  var Component = require('Component');

  var template = require('/template/main');

  var thanksTemplate = require('/template/thanks');

  var membersTemplate = require('/template/members');

  var editTemplate = require('/template/edit');

  return Component.extend({
    getTemplate: function getTemplate() {
      if (this.state.route === '/signup') {
        return thanksTemplate;
      }

      if (this.state.route === '/members') {
        return membersTemplate;
      }

      if (this.state.route === '/edit') {
        return editTemplate;
      }

      return template;
    },
    className: 'webapp-boilerplate',
    filterState: function filterState(_ref) {
      var route = _ref.route,
          name = _ref.name;
      return {
        route: route,
        name: name
      };
    }
  });
});