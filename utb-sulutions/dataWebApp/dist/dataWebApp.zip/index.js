/* eslint-disable import/no-absolute-path */

/* eslint-disable import/no-unresolved */

/* eslint-disable global-require */
(function init() {
  var router = require('router');

  var appData = require('appData');

  var storage = require('storage');

  var logUtil = require('LogUtil');

  var dataStore = storage.getCollectionDataStore('members2');

  var dataStoreProvider = require('/module/server/dataStoreProvider');

  router.get('/', function (req, res) {
    var message = 'Hello, world!';
    var name = appData.get('name');
    res.render('/', {
      message: message,
      name: name
    });
  });
  router.post('/signup', function (req, res) {
    var member = {
      name: req.params.name,
      email: req.params.email,
      age: req.params.age
    };

    try {
      var data = dataStore.add(member);
      dataStore.instantIndex(data.dsid);
      res.render('/signup', {
        name: data.name
      });
    } catch (e) {
      logUtil.error(e);
    }
  });
  router.get('/members', function (req, res) {
    res.render('/members', {
      members: dataStoreProvider.getAllMembers()
    });
  });
  router.get('/edit', function (req, res) {
    try {
      var member = dataStore.get(req.params.id);
      res.render('/edit', {
        member: member
      });
    } catch (e) {
      logUtil.error(e);
    }
  });
  router.post('/editMember', function (req, res) {
    var member = {
      name: req.params.name,
      email: req.params.email,
      age: parseInt(req.params.age, 10)
    };
    dataStoreProvider.editMember(req.params.dsid, member);
    res.render('/members', {
      members: dataStoreProvider.getAllMembers()
    });
  });
  router.post('/remove', function (req, res) {
    dataStoreProvider.remove(req.params.dsid);
    res.render('/members', {
      members: dataStoreProvider.getAllMembers()
    });
  });
  router.post('/search', function (req, res) {
    res.render('/members', {
      members: dataStoreProvider.search(req.params.name)
    });
  });
})();