/* eslint-disable consistent-return */

/* eslint-disable import/no-unresolved */

/* eslint-disable no-undef */
// /module/server/dataStoreProvider.js
define(function (require) {
  var storage = require('storage');

  var members = storage.getCollectionDataStore('members2');

  var logUtil = require('LogUtil'); // Define this module


  return {
    getAllMembers: function getAllMembers() {
      var result = members.find('*', 100);

      try {
        data = result.toArray();
        return data;
      } catch (e) {
        logUtil.error(e);
        return false;
      }
    },
    editMember: function editMember(id, member) {
      try {
        var updateMember = members.set(id, member);
        updateMember.instantIndex();
      } catch (e) {
        logUtil.error(e);
      }

      return true;
    },
    remove: function remove(id) {
      try {
        var removeMember = members.remove(id);
        removeMember.instantIndex();
      } catch (e) {
        logUtil.error(e);
      }
    },
    search: function search(condition) {
      var query = "ds.analyzed.name:".concat(condition, "*");
      var results = members.find(query, 100);

      try {
        data = results.toArray();
        return data;
      } catch (e) {
        logUtil.error(e);
      }
    }
  };
});