/* eslint-disable import/no-unresolved */

/* eslint-disable no-undef */
define(function (require) {
  var ListComponent = require('ListComponent');

  return ListComponent.extend({
    tagName: 'ul',
    childProperty: 'members',
    childComponentPath: 'Member',
    filterState: function filterState(_ref) {
      var members = _ref.members;
      return {
        members: members
      };
    }
  });
});