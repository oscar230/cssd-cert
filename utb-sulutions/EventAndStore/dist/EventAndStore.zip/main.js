define(function (require) {
  'use strict';

  var Component = require('Component');

  var template = require('/template/main');

  return Component.extend({
    template: template,
    className: 'webapp-boilerplate main-wrapper env-p-around--small env-m-around-small',
    filterState: function filterState(_ref) {
      var pageName = _ref.pageName;
      return {
        pageName: pageName
      };
    }
  });
});