(function () {
  'use strict';

  var router = require('router');

  var appData = require('appData');

  router.get('/', function (req, res) {
    var pageName = appData.get("page", "displayName");
    res.render('/', {
      pageName: pageName
    });
  });
  router.get("/getProperty", function (req, res) {
    res.json({
      property: req.params.property,
      propertyValue: appData.get("page", req.params.property)
    });
  });
})();