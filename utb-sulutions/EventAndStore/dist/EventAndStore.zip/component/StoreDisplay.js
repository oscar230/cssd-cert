define(function (require) {
  'use strict';

  var Component = require('Component');

  var _ = require('underscore');

  var template = require('/template/storeDisplay');

  return Component.extend({
    template: template,
    className: "storeDisplay-wrapper env-p-around--small env-m-around--small",
    events: {
      store: "handleStoreUpdate",
      self: {
        "state:changed": "render"
      }
    },
    handleStoreUpdate: function handleStoreUpdate(newState) {
      this.setState(newState);
    },
    filterState: function filterState(state) {
      return _.extend({}, {
        state: state
      });
    }
  });
});