define(function (require) {
  'use strict';

  var Component = require('Component');

  var _ = require('underscore');

  var template = require('/template/propertyDisplay');

  return Component.extend({
    template: template,
    className: "propertyDisplay-wrapper env-p-around--small env-m-around--small",
    events: {
      store: "handleStoreUpdate",
      self: {
        "state:changed": "render"
      }
    },
    handleStoreUpdate: function handleStoreUpdate(newState) {
      this.setState(newState);
    },
    filterState: function filterState(_ref) {
      var property = _ref.property,
          propertyValue = _ref.propertyValue;
      return {
        property: property,
        propertyValue: propertyValue
      };
    }
  });
});