define(function (require) {
  'use strict';

  var Component = require('Component');

  var template = require('/template/propertyForm');

  var _ = require('underscore');

  var requester = require('requester');

  var router = require('router');

  var store = require('store');

  return Component.extend({
    template: template,
    className: 'property-wrapper env-p-around--small env-m-around--small',
    events: {
      dom: {
        'click [data-get-property]': 'handleGetProperty'
      }
    },
    handleGetProperty: function handleGetProperty() {
      requester.doGet({
        url: router.getUrl('/getProperty'),
        data: {
          property: this.$('[data-property]').val()
        },
        context: this
      }).done(function (response) {
        console.log(JSON.stringify(response));
        store.dispatch({
          type: 'SET_PROPERTY_VALUE',
          property: response.property,
          propertyValue: response.propertyValue
        });
        this.$("[data-property]").val("");
      });
    }
  });
});